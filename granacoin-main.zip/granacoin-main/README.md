# Token-Granacoin-Graco BEP20
Token Graco Red BSC

* Contract: https://bscscan.com/address/0x84aea9789137bfef54915d21dad85ecbdcdf840b
* Contract Test: https://testnet.bscscan.com/address/0xa03161074d5e23882bd233f1c92b1b6397f29c7c
* Source: https://github.com/granacoin/granacoin/blob/main/gracocoin.sol

 Block Genesis Token 
==========================
* - Total Supply: 15.000.000 GRACO token
* - Initial Supply: 15.000.000 GRACO Token


Whitepaper Token
==========================
* Spanish: https://github.com/granacoin/granacoin/blob/main/doc/whitepaper-es.md
* English: https://github.com/granacoin/granacoin/blob/main/doc/whitepaper-en.md

Audit Docs
=========================
* https://github.com/granacoin/granacoin/blob/main/doc/No2Acta-02CertificadoAuditoriaGranacoinGraco12Diciembre2021.pdf
* https://github.com/granacoin/granacoin/blob/main/doc/granacoin-graco-audit_report.md

### Audit Blockchain Technology SAS
Cert: https://github.com/blockchaintechnologysas/audit/blob/main/cert/No2Acta-02CertificadoAuditoriaGranacoinGraco12Diciembre2021.pdf

### Backup Company
UNIVERSO DE LOS COSMETICOS S.A.S.
NIT 900747059-5
Web: https://www.universodelcosmetico.co/
