All copyright Granacoin Community 2018 - 2022
